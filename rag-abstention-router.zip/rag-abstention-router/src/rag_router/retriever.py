"""Retrievers. BM25 is implemented here with scikit-learn (no extra dependency)."""
from __future__ import annotations

import numpy as np
from scipy import sparse
from sklearn.feature_extraction.text import CountVectorizer


class BM25Retriever:
    def __init__(self, texts: list[str], k1: float = 1.5, b: float = 0.75):
        self.vec = CountVectorizer(stop_words="english", lowercase=True,
                                   token_pattern=r"(?u)\b\w+\b")
        tf = self.vec.fit_transform(texts).tocsr().astype(np.float32)
        n_docs = tf.shape[0]
        df = np.asarray((tf > 0).sum(axis=0)).ravel()
        idf = np.log(1.0 + (n_docs - df + 0.5) / (df + 0.5))
        dl = np.asarray(tf.sum(axis=1)).ravel()
        avgdl = max(dl.mean(), 1e-9)
        coo = tf.tocoo()
        denom = coo.data + k1 * (1 - b + b * dl[coo.row] / avgdl)
        w = coo.data * (k1 + 1) / denom * idf[coo.col]
        self.W = sparse.csr_matrix((w, (coo.row, coo.col)), shape=tf.shape).T.tocsr()  # terms x docs
        self.n_docs = n_docs

    def search(self, queries: list[str], k: int, chunk: int = 256):
        k = min(k, self.n_docs)
        all_idx, all_sc = [], []
        for s in range(0, len(queries), chunk):
            q = self.vec.transform(queries[s:s + chunk]).tocsr()
            q.data[:] = 1.0  # binary query term weights
            scores = (q @ self.W).toarray()
            top = np.argpartition(-scores, k - 1, axis=1)[:, :k]
            top_sc = np.take_along_axis(scores, top, axis=1)
            order = np.argsort(-top_sc, axis=1)
            all_idx.append(np.take_along_axis(top, order, axis=1))
            all_sc.append(np.take_along_axis(top_sc, order, axis=1))
        return np.vstack(all_idx), np.vstack(all_sc)


class DenseRetriever:
    def __init__(self, texts: list[str], model_name: str, device: str = "auto"):
        from sentence_transformers import SentenceTransformer
        dev = None if device == "auto" else device
        self.model = SentenceTransformer(model_name, device=dev)
        self.emb = self.model.encode(texts, batch_size=64, normalize_embeddings=True,
                                     show_progress_bar=False)
        self.n_docs = len(texts)

    def search(self, queries: list[str], k: int):
        k = min(k, self.n_docs)
        q = self.model.encode(queries, batch_size=64, normalize_embeddings=True,
                              show_progress_bar=False)
        scores = q @ self.emb.T
        top = np.argpartition(-scores, k - 1, axis=1)[:, :k]
        top_sc = np.take_along_axis(scores, top, axis=1)
        order = np.argsort(-top_sc, axis=1)
        return np.take_along_axis(top, order, axis=1), np.take_along_axis(top_sc, order, axis=1)


def build_retriever(cfg, texts: list[str]):
    if cfg.retriever == "bm25":
        return BM25Retriever(texts)
    if cfg.retriever == "dense":
        return DenseRetriever(texts, cfg.dense_model, cfg.device)
    raise ValueError(f"Unknown retriever {cfg.retriever!r}")
