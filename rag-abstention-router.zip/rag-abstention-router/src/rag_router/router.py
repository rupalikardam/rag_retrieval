"""Feature-based routers: predict the oracle action from cheap signals."""
from __future__ import annotations

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

from .features import FEATURE_GROUPS

# name -> feature groups. Names are what shows up in the results table.
ROUTER_VARIANTS: dict[str, list[str]] = {
    "router[query]": ["query"],
    "router[query+retr]": ["query", "retr"],
    "router[query+param]": ["query", "param"],
    "router[query+param+retr]": ["query", "param", "retr"],
    "router[query+param+retr+rag]": ["query", "param", "retr", "rag"],
}


def feature_columns(groups: list[str]) -> list[str]:
    return [c for g in groups for c in FEATURE_GROUPS[g]]


class _Constant:
    """Fallback when the training split contains a single class."""
    def __init__(self, label: int):
        self.classes_ = np.array([label])

    def predict(self, X):
        return np.full(len(X), self.classes_[0])


class Router:
    def __init__(self, groups: list[str], model: str = "hgb", seed: int = 42):
        self.groups, self.cols = groups, feature_columns(groups)
        self.model_name, self.seed = model, seed
        self.model = None

    def _make(self):
        if self.model_name == "hgb":
            return HistGradientBoostingClassifier(max_depth=4, learning_rate=0.05, max_iter=200,
                                                  class_weight="balanced", random_state=self.seed)
        if self.model_name == "logreg":
            return make_pipeline(StandardScaler(),
                                 LogisticRegression(max_iter=2000, class_weight="balanced"))
        raise ValueError(f"Unknown router model {self.model_name!r}")

    def fit(self, df: pd.DataFrame, labels: np.ndarray) -> "Router":
        X = df[self.cols].to_numpy(dtype=float)
        if len(np.unique(labels)) == 1:
            self.model = _Constant(int(labels[0]))
        else:
            self.model = self._make().fit(X, labels)
        return self

    def predict(self, df: pd.DataFrame) -> np.ndarray:
        return np.asarray(self.model.predict(df[self.cols].to_numpy(dtype=float))).astype(int)

    def save(self, path) -> None:
        joblib.dump(self, path)

    @staticmethod
    def load(path) -> "Router":
        return joblib.load(path)
