"""Generators. Both expose the same two methods, each returning [(text, confidence)].

confidence = exp(mean token log-prob) of the generated answer, in (0, 1].
"""
from __future__ import annotations

import hashlib
import json
import logging
import re
from pathlib import Path

import numpy as np

log = logging.getLogger(__name__)

CLOSED_BOOK_PROMPT = "Answer the following question with a short answer.\n\n{q}"
RAG_PROMPT = "Read this and answer the question.\n\n{ctx}\n\n{q}"


def join_contexts(contexts: list[str], max_chars: int) -> str:
    return "\n\n".join(contexts)[:max_chars]


class HFSeq2SeqGenerator:
    """Works with any encoder-decoder model on the Hub (Flan-T5 small/base/large...)."""

    def __init__(self, model_name: str, device: str = "auto", batch_size: int = 16,
                 max_new_tokens: int = 16, max_input_tokens: int = 640, max_context_chars: int = 2400):
        import torch
        from transformers import AutoModelForSeq2SeqLM, AutoTokenizer
        self.torch = torch
        self.device = ("cuda" if torch.cuda.is_available() else "cpu") if device == "auto" else device
        log.info("Loading %s on %s", model_name, self.device)
        self.tok = AutoTokenizer.from_pretrained(model_name)
        self.model = AutoModelForSeq2SeqLM.from_pretrained(model_name).to(self.device).eval()
        self.bs, self.max_new, self.max_in = batch_size, max_new_tokens, max_input_tokens
        self.max_chars = max_context_chars

    def _run(self, prompts: list[str]) -> list[tuple[str, float]]:
        torch, out = self.torch, []
        for i in range(0, len(prompts), self.bs):
            batch = prompts[i:i + self.bs]
            enc = self.tok(batch, return_tensors="pt", padding=True, truncation=True,
                           max_length=self.max_in).to(self.device)
            with torch.no_grad():
                gen = self.model.generate(**enc, max_new_tokens=self.max_new, do_sample=False,
                                          output_scores=True, return_dict_in_generate=True)
            trans = self.model.compute_transition_scores(gen.sequences, gen.scores, normalize_logits=True)
            gen_tokens = gen.sequences[:, 1:]  # drop decoder start token (encoder-decoder models)
            texts = self.tok.batch_decode(gen.sequences, skip_special_tokens=True)
            for j in range(len(batch)):
                mask = gen_tokens[j] != self.tok.pad_token_id
                lp = trans[j][mask]
                lp = lp[torch.isfinite(lp)]
                conf = float(torch.exp(lp.mean()).item()) if lp.numel() else 0.0
                out.append((texts[j].strip(), conf))
            log.info("generated %d/%d", min(i + self.bs, len(prompts)), len(prompts))
        return out

    def closed_book(self, questions):
        return self._run([CLOSED_BOOK_PROMPT.format(q=q) for q in questions])

    def with_context(self, questions, contexts):
        return self._run([RAG_PROMPT.format(ctx=join_contexts(c, self.max_chars), q=q)
                          for q, c in zip(questions, contexts)])


def _u(*parts: str) -> float:
    """Deterministic pseudo-random number in [0,1) from strings (stable across runs)."""
    h = hashlib.md5("|".join(parts).encode()).hexdigest()
    return int(h[:8], 16) / 0x100000000


class MockGenerator:
    """Offline stand-in for an LLM, used ONLY with the synthetic dataset (tests / demo).

    Closed-book: knows a fixed subset of facts. With context: extracts the matching
    sentence; otherwise guesses, sometimes confidently (a realistic failure mode).
    """

    Q_RE = re.compile(r"What is the (\w+) of (\w+)\?")
    C_RE = re.compile(r"The (\w+) of (\w+) is (\w+)\.")

    def __init__(self, known: dict[str, str]):
        self.known = known

    @classmethod
    def from_data_dir(cls, d: Path):
        p = Path(d) / "known_facts.json"
        if not p.exists():
            raise FileNotFoundError("generator=mock only works with dataset=synthetic")
        return cls(json.loads(p.read_text()))

    def closed_book(self, questions):
        out = []
        for q in questions:
            if q in self.known:
                out.append((self.known[q], 0.85 + 0.1 * _u(q, "k")))
            else:
                out.append((f"Guess{int(_u(q, 'g') * 1000)}", 0.15 + 0.4 * _u(q, "c")))
        return out

    def with_context(self, questions, contexts):
        out = []
        for q, ctx in zip(questions, contexts):
            m = self.Q_RE.match(q)
            text = " ".join(ctx)
            if m:
                attr, ent = m.groups()
                for a, e, v in self.C_RE.findall(text):
                    if a == attr and e == ent:
                        out.append((v, 0.8 + 0.15 * _u(q, "r")))
                        break
                else:
                    caps = re.findall(r"\b[A-Z]\w+", text) or ["None"]
                    pick = caps[int(_u(q, "p") * len(caps))]
                    lure = _u(q, "lure") < 0.2  # sometimes the model is confidently wrong
                    out.append((pick, 0.7 + 0.1 * _u(q, "lc") if lure else 0.2 + 0.35 * _u(q, "wc")))
            else:
                out.append(("None", 0.1))
        return out


def build_generator(cfg, data_dir: Path):
    if cfg.generator == "mock":
        return MockGenerator.from_data_dir(data_dir)
    return HFSeq2SeqGenerator(cfg.generator, cfg.device, cfg.batch_size, cfg.max_new_tokens,
                              cfg.max_input_tokens, cfg.max_context_chars)
