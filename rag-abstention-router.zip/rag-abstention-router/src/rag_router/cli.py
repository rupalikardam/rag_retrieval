"""python -m rag_router --config configs/xxx.yaml {prepare|label|train|evaluate|all}"""
from __future__ import annotations

import argparse
import dataclasses
import json
import logging
from pathlib import Path

from .config import Config, load_config
from .data import load_data, prepare_data
from .evaluate import evaluate, train_routers
from .labeling import outcomes_path, run_labeling


def run_all(cfg: Config):
    Path(cfg.run_dir).mkdir(parents=True, exist_ok=True)
    (Path(cfg.run_dir) / "config_used.json").write_text(json.dumps(dataclasses.asdict(cfg), indent=2))
    q, c = prepare_data(cfg)
    run_labeling(cfg, q, c)
    train_routers(cfg)
    return evaluate(cfg)


def main(argv=None):
    ap = argparse.ArgumentParser(prog="rag_router")
    ap.add_argument("stage", choices=["prepare", "label", "train", "evaluate", "all"])
    ap.add_argument("--config", default=None)
    ap.add_argument("--set", nargs="*", default=[], metavar="KEY=VALUE",
                    help="override config values, e.g. --set n_questions=500 generator=google/flan-t5-small")
    args = ap.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s", datefmt="%H:%M:%S")

    import yaml
    overrides = {k: yaml.safe_load(v) for k, v in (s.split("=", 1) for s in args.set)}
    cfg = load_config(args.config, overrides)

    if args.stage == "all":
        res = run_all(cfg)
    elif args.stage == "prepare":
        prepare_data(cfg)
        return
    elif args.stage == "label":
        q, c = load_data(cfg)
        run_labeling(cfg, q, c)
        return
    elif args.stage == "train":
        train_routers(cfg)
        return
    else:
        res = evaluate(cfg)
    print("\n" + (Path(cfg.run_dir) / "results" / "results.md").read_text())


if __name__ == "__main__":
    main()
