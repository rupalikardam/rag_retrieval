"""SQuAD-style answer normalisation and correctness."""
from __future__ import annotations

import re
import string
from collections import Counter


def normalize_answer(s: str) -> str:
    s = s.lower()
    s = "".join(ch for ch in s if ch not in set(string.punctuation))
    s = re.sub(r"\b(a|an|the)\b", " ", s)
    return " ".join(s.split())


def f1_score(pred: str, gold: str) -> float:
    p, g = normalize_answer(pred).split(), normalize_answer(gold).split()
    if not p or not g:
        return float(p == g)
    common = Counter(p) & Counter(g)
    n_same = sum(common.values())
    if n_same == 0:
        return 0.0
    precision, recall = n_same / len(p), n_same / len(g)
    return 2 * precision * recall / (precision + recall)


def is_correct(pred: str, golds: list[str], threshold: float = 0.5) -> bool:
    """Unanswerable questions (no gold answers) can never be answered correctly."""
    if not golds:
        return False
    return max(f1_score(pred, g) for g in golds) >= threshold
