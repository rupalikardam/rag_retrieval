"""The decision problem: 3 actions, one utility function, one oracle."""
from __future__ import annotations

import numpy as np
import pandas as pd

ACTIONS = ["no_retrieve", "retrieve", "abstain"]
NO_RETRIEVE, RETRIEVE, ABSTAIN = 0, 1, 2


def action_utilities(df: pd.DataFrame, retrieval_cost: float, wrong_penalty: float) -> np.ndarray:
    """(n, 3) matrix of the utility each action would earn on each question.

      correct answer = +1;  wrong answer = -wrong_penalty;  retrieval costs `retrieval_cost`
      abstaining: +1 if the question is unanswerable, else 0
    """
    cb = df["cb_correct"].to_numpy().astype(bool)
    rag = df["rag_correct"].to_numpy().astype(bool)
    ans = df["is_answerable"].to_numpy().astype(bool)
    u0 = np.where(cb, 1.0, -wrong_penalty)
    u1 = np.where(rag, 1.0, -wrong_penalty) - retrieval_cost
    u2 = np.where(ans, 0.0, 1.0)
    return np.stack([u0, u1, u2], axis=1)


def oracle_actions(U: np.ndarray) -> np.ndarray:
    """Best action per question. Ties go to the cheaper action (no_retrieve < abstain < retrieve)."""
    priority = np.array([0, 2, 1])  # column order to scan on ties
    return priority[np.argmax(U[:, priority], axis=1)]
