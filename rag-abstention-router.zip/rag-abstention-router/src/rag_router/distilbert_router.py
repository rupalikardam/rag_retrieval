"""EXPERIMENTAL: query-text-only DistilBERT router (the 'low-compute' pivot).

Needs torch + transformers + internet for the weights. Not exercised by the offline tests.
It sees only the question text, so it costs ~one tiny forward pass and no retrieval/LLM call.
"""
from __future__ import annotations

import logging

import numpy as np

log = logging.getLogger(__name__)


def train_and_predict(train_q, train_y, pred_q, epochs=3, lr=5e-5, batch_size=32,
                      max_len=48, seed=42, device="auto", model_name="distilbert-base-uncased"):
    import torch
    from transformers import AutoModelForSequenceClassification, AutoTokenizer

    torch.manual_seed(seed)
    np.random.seed(seed)
    dev = ("cuda" if torch.cuda.is_available() else "cpu") if device == "auto" else device
    tok = AutoTokenizer.from_pretrained(model_name)
    model = AutoModelForSequenceClassification.from_pretrained(model_name, num_labels=3).to(dev)

    y = np.asarray(train_y)
    counts = np.bincount(y, minlength=3).astype(float)
    weights = torch.tensor(np.where(counts > 0, len(y) / (3 * np.maximum(counts, 1)), 0.0),
                           dtype=torch.float, device=dev)
    loss_fn = torch.nn.CrossEntropyLoss(weight=weights)
    opt = torch.optim.AdamW(model.parameters(), lr=lr)

    def enc(texts):
        return tok(list(texts), return_tensors="pt", padding=True, truncation=True,
                   max_length=max_len).to(dev)

    n = len(train_q)
    for ep in range(epochs):
        model.train()
        perm = np.random.permutation(n)
        total = 0.0
        for s in range(0, n, batch_size):
            b = perm[s:s + batch_size]
            batch = enc([train_q[i] for i in b])
            labels = torch.tensor(y[b], dtype=torch.long, device=dev)
            loss = loss_fn(model(**batch).logits, labels)
            opt.zero_grad()
            loss.backward()
            opt.step()
            total += loss.item() * len(b)
        log.info("distilbert epoch %d/%d loss=%.4f", ep + 1, epochs, total / n)

    model.eval()
    preds = []
    with torch.no_grad():
        for s in range(0, len(pred_q), 64):
            logits = model(**enc(pred_q[s:s + 64])).logits
            preds.extend(logits.argmax(-1).cpu().tolist())
    return np.array(preds, dtype=int)
