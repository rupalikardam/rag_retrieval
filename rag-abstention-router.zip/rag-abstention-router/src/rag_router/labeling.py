"""Run the generator with and without retrieval on every question and record the outcomes.

This is the expensive stage (2 LLM passes). Its output, outcomes.csv, contains everything
the routers and the evaluation need, so training/evaluating never touches the LLM again.
"""
from __future__ import annotations

import json
import logging

import numpy as np
import pandas as pd

from .config import Config
from .data import data_dir
from .features import answer_words, query_features, retrieval_features
from .generator import build_generator
from .metrics import is_correct
from .retriever import build_retriever

log = logging.getLogger(__name__)


def outcomes_path(cfg: Config):
    return data_dir(cfg) / "outcomes.csv"


def run_labeling(cfg: Config, questions: pd.DataFrame, corpus: pd.DataFrame) -> pd.DataFrame:
    texts = corpus["text"].tolist()
    qs = questions["question"].tolist()

    log.info("Retrieving top-%d passages for %d questions (%s)", cfg.top_k, len(qs), cfg.retriever)
    retr = build_retriever(cfg, texts)
    idx, sc = retr.search(qs, cfg.top_k)
    contexts = [[texts[j] for j in row] for row in idx]

    gen = build_generator(cfg, data_dir(cfg))
    log.info("Closed-book pass (no retrieval)")
    cb = gen.closed_book(qs)
    log.info("RAG pass (with retrieved context)")
    rag = gen.with_context(qs, contexts)

    rows = []
    for i, r in enumerate(questions.itertuples(index=False)):
        golds = list(r.answers)
        gold_pid = int(r.gold_passage)
        row = {
            "id": r.id, "split": r.split, "question": r.question, "answers": json.dumps(golds),
            "is_answerable": bool(r.is_answerable),
            "retrieved_ids": json.dumps([int(x) for x in idx[i]]),
            "gold_in_topk": bool(gold_pid >= 0 and gold_pid in idx[i]),
            "gold_at_top1": bool(gold_pid >= 0 and gold_pid == idx[i][0]),
            "cb_text": cb[i][0], "cb_conf": cb[i][1], "cb_ans_words": answer_words(cb[i][0]),
            "cb_correct": is_correct(cb[i][0], golds, cfg.f1_threshold),
            "rag_text": rag[i][0], "rag_conf": rag[i][1], "rag_ans_words": answer_words(rag[i][0]),
            "rag_correct": is_correct(rag[i][0], golds, cfg.f1_threshold),
        }
        row.update(query_features(r.question))
        row.update(retrieval_features(r.question, contexts[i], sc[i]))
        rows.append(row)

    out = pd.DataFrame(rows)
    out.to_csv(outcomes_path(cfg), index=False)
    log_label_stats(out)
    return out


def log_label_stats(df: pd.DataFrame) -> None:
    a = df[df["is_answerable"]]
    log.info("Answerable: closed-book acc=%.3f | RAG acc=%.3f | gold passage in top-k=%.3f",
             a["cb_correct"].mean(), a["rag_correct"].mean(), a["gold_in_topk"].mean())
