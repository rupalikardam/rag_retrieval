"""Tiny fully-offline QA world used for tests and for sanity-checking the pipeline.

Each entity has 3 of 5 attributes written into its passage. Questions about the
other 2 attributes, or about entities absent from the corpus, are unanswerable.
"""
from __future__ import annotations

import numpy as np

SYL = ["bar", "kel", "zor", "mi", "tan", "qui", "lo", "ven", "dra", "sul", "pha", "rin", "gor", "eli", "nox"]
ATTRS = ["capital", "currency", "language", "river", "leader"]


def build_synthetic(n_entities: int = 300, seed: int = 0, known_frac: float = 0.25):
    rng = np.random.default_rng(seed)
    used: set[str] = set()

    def name() -> str:
        while True:
            n = "".join(rng.choice(SYL, size=int(rng.integers(3, 5)))).capitalize()
            if n not in used:
                used.add(n)
                return n

    corpus, questions, known = [], [], {}
    qid = 0
    for e_idx in range(n_entities):
        ent = name()
        present = set(rng.choice(len(ATTRS), size=3, replace=False).tolist())
        sentences = [f"{ent} is a country."]
        for a_idx, attr in enumerate(ATTRS):
            q = f"What is the {attr} of {ent}?"
            if a_idx in present:
                val = name()
                sentences.append(f"The {attr} of {ent} is {val}.")
                questions.append({"id": f"s{qid}", "question": q, "answers": [val],
                                  "is_answerable": True, "gold_passage": e_idx})
                if rng.random() < known_frac:
                    known[q] = val
            else:
                questions.append({"id": f"s{qid}", "question": q, "answers": [],
                                  "is_answerable": False, "gold_passage": e_idx})
            qid += 1
        corpus.append({"passage_id": e_idx, "text": " ".join(sentences)})
    for _ in range(n_entities // 2):  # entities that are not in the corpus at all
        attr = ATTRS[int(rng.integers(len(ATTRS)))]
        questions.append({"id": f"s{qid}", "question": f"What is the {attr} of {name()}?",
                          "answers": [], "is_answerable": False, "gold_passage": -1})
        qid += 1
    return questions, corpus, known
