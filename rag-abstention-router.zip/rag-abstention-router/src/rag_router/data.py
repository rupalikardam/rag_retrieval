"""Dataset preparation. Output: questions.jsonl + corpus.jsonl in <run_dir>/data."""
from __future__ import annotations

import json
import logging
from pathlib import Path

import numpy as np
import pandas as pd

from .config import Config

log = logging.getLogger(__name__)


def data_dir(cfg: Config) -> Path:
    d = Path(cfg.run_dir) / "data"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _stratified_sample(rows: list[dict], n: int, unans_frac: float, rng) -> list[dict]:
    ans = [r for r in rows if r["is_answerable"]]
    un = [r for r in rows if not r["is_answerable"]]
    n_un = min(int(round(n * unans_frac)), len(un))
    n_an = min(n - n_un, len(ans))
    pick = [ans[i] for i in rng.choice(len(ans), n_an, replace=False)] + \
           [un[i] for i in rng.choice(len(un), n_un, replace=False)]
    rng.shuffle(pick)
    return pick


def _load_squad_v2() -> tuple[list[dict], list[dict]]:
    from datasets import load_dataset  # needs `pip install datasets` + internet
    ds = load_dataset("rajpurkar/squad_v2", split="validation")
    ctx_ids: dict[str, int] = {}
    corpus, rows = [], []
    for ex in ds:
        c = ex["context"]
        if c not in ctx_ids:
            ctx_ids[c] = len(ctx_ids)
            corpus.append({"passage_id": ctx_ids[c], "text": c})
        golds = list(dict.fromkeys(ex["answers"]["text"]))
        rows.append({"id": ex["id"], "question": ex["question"], "answers": golds,
                     "is_answerable": len(golds) > 0, "gold_passage": ctx_ids[c]})
    return rows, corpus


def _load_jsonl(cfg: Config) -> tuple[list[dict], list[dict]]:
    """Bring-your-own domain (legal / medical FAQ...).

    questions file: one JSON per line: {"question": ..., "answers": [...], "context": "..."(optional)}
    Empty/missing `answers` => unanswerable. `context` is the passage the question came from.
    corpus file (optional): {"text": ...} per line; extra distractor passages.
    """
    texts: dict[str, int] = {}
    corpus: list[dict] = []

    def pid(t: str) -> int:
        if t not in texts:
            texts[t] = len(texts)
            corpus.append({"passage_id": texts[t], "text": t})
        return texts[t]

    rows = []
    for i, line in enumerate(Path(cfg.questions_path).read_text().splitlines()):
        if not line.strip():
            continue
        r = json.loads(line)
        golds = [a for a in (r.get("answers") or []) if a]
        ctx = r.get("context")
        rows.append({"id": str(r.get("id", i)), "question": r["question"], "answers": golds,
                     "is_answerable": len(golds) > 0, "gold_passage": pid(ctx) if ctx else -1})
    if cfg.corpus_path:
        for line in Path(cfg.corpus_path).read_text().splitlines():
            if line.strip():
                pid(json.loads(line)["text"])
    return rows, corpus


def assign_splits(df: pd.DataFrame, train_frac: float, dev_frac: float, seed: int) -> pd.DataFrame:
    """Split by *group* (source passage) so near-duplicate questions never straddle splits."""
    rng = np.random.default_rng(seed)
    groups = np.array(sorted(df["group"].unique()))
    rng.shuffle(groups)
    n = len(groups)
    n_tr, n_dev = int(round(n * train_frac)), int(round(n * dev_frac))
    mapping = {g: ("train" if i < n_tr else "dev" if i < n_tr + n_dev else "test")
               for i, g in enumerate(groups)}
    df = df.copy()
    df["split"] = df["group"].map(mapping)
    if set(df["split"]) != {"train", "dev", "test"}:
        raise ValueError("Too little data to fill train/dev/test; increase n_questions.")
    return df


def prepare_data(cfg: Config) -> tuple[pd.DataFrame, pd.DataFrame]:
    rng = np.random.default_rng(cfg.seed)
    known = None
    if cfg.dataset == "squad_v2":
        rows, corpus = _load_squad_v2()
    elif cfg.dataset == "synthetic":
        from .synthetic import build_synthetic
        rows, corpus, known = build_synthetic(seed=cfg.seed)
    elif cfg.dataset == "jsonl":
        rows, corpus = _load_jsonl(cfg)
    else:
        raise ValueError(f"Unknown dataset {cfg.dataset!r}")

    rows = _stratified_sample(rows, cfg.n_questions, cfg.unanswerable_fraction, rng)
    q = pd.DataFrame(rows)
    # questions with no source passage get their own group
    q["group"] = [g if g >= 0 else -(i + 1) for i, g in enumerate(q["gold_passage"])]
    q = assign_splits(q, cfg.train_frac, cfg.dev_frac, cfg.seed)
    c = pd.DataFrame(corpus)
    assert (c["passage_id"].to_numpy() == np.arange(len(c))).all(), "passage_id must equal row index"

    d = data_dir(cfg)
    q.to_json(d / "questions.jsonl", orient="records", lines=True)
    c.to_json(d / "corpus.jsonl", orient="records", lines=True)
    if known is not None:
        (d / "known_facts.json").write_text(json.dumps(known))
    log.info("Prepared %d questions (%.0f%% unanswerable) over a corpus of %d passages",
             len(q), 100 * (~q["is_answerable"]).mean(), len(c))
    log.info("Split sizes: %s", q["split"].value_counts().to_dict())
    return q, c


def load_data(cfg: Config) -> tuple[pd.DataFrame, pd.DataFrame]:
    d = data_dir(cfg)
    return (pd.read_json(d / "questions.jsonl", lines=True, dtype={"id": str}),
            pd.read_json(d / "corpus.jsonl", lines=True))
