"""Cheap, interpretable router features, in four groups (used for ablations)."""
from __future__ import annotations

import re

import numpy as np
from sklearn.feature_extraction.text import ENGLISH_STOP_WORDS

WH = ["what", "who", "when", "where", "which", "why", "how"]
_tok = re.compile(r"\w+")

FEATURE_GROUPS: dict[str, list[str]] = {
    "query": ["q_words", "q_chars", "q_caps", "q_has_digit", "q_content_words"] + [f"wh_{w}" for w in WH] + ["wh_other"],
    "param": ["cb_conf", "cb_ans_words"],                       # closed-book LLM signal
    "retr": ["ret_top1", "ret_top2", "ret_gap", "ret_mean", "ret_std", "ret_top1_share", "ret_coverage"],
    "rag": ["rag_conf", "rag_ans_words"],                       # post-hoc: needs a full RAG call
}


def query_features(q: str) -> dict[str, float]:
    toks = _tok.findall(q)
    first = toks[0].lower() if toks else ""
    f = {
        "q_words": len(toks),
        "q_chars": len(q),
        "q_caps": sum(t[0].isupper() for t in toks[1:]),
        "q_has_digit": float(any(c.isdigit() for c in q)),
        "q_content_words": sum(t.lower() not in ENGLISH_STOP_WORDS for t in toks),
    }
    for w in WH:
        f[f"wh_{w}"] = float(first == w)
    f["wh_other"] = float(first not in WH)
    return f


def retrieval_features(question: str, top_texts: list[str], scores: np.ndarray) -> dict[str, float]:
    s = np.zeros(max(len(scores), 2))
    s[:len(scores)] = scores
    q_content = {t.lower() for t in _tok.findall(question)} - ENGLISH_STOP_WORDS
    doc_toks = {t.lower() for t in _tok.findall(top_texts[0])} if top_texts else set()
    coverage = len(q_content & doc_toks) / len(q_content) if q_content else 0.0
    return {
        "ret_top1": float(s[0]), "ret_top2": float(s[1]), "ret_gap": float(s[0] - s[1]),
        "ret_mean": float(s[:len(scores)].mean() if len(scores) else 0.0),
        "ret_std": float(s[:len(scores)].std() if len(scores) else 0.0),
        "ret_top1_share": float(s[0] / (s.sum() + 1e-9)),
        "ret_coverage": coverage,
    }


def answer_words(text: str) -> int:
    return len(_tok.findall(text))
