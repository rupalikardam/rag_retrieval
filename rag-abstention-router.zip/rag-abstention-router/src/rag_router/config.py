"""Single source of truth for every experiment knob. Loaded from YAML."""
from __future__ import annotations

import dataclasses
from dataclasses import dataclass
from pathlib import Path

import yaml


@dataclass
class Config:
    seed: int = 42
    run_dir: str = "runs/squad_flan_t5_base"

    # ---- data ----
    dataset: str = "squad_v2"          # squad_v2 | synthetic | jsonl
    questions_path: str = ""            # for dataset=jsonl
    corpus_path: str = ""               # optional extra passages for dataset=jsonl
    n_questions: int = 2000
    unanswerable_fraction: float = 0.5
    train_frac: float = 0.6
    dev_frac: float = 0.2               # test = remainder

    # ---- retriever ----
    retriever: str = "bm25"             # bm25 | dense
    dense_model: str = "sentence-transformers/all-MiniLM-L6-v2"
    top_k: int = 3

    # ---- generator ----
    generator: str = "google/flan-t5-base"   # any HF seq2seq model, or "mock"
    device: str = "auto"
    batch_size: int = 16
    max_new_tokens: int = 16
    max_input_tokens: int = 640
    max_context_chars: int = 2400

    # ---- scoring / utility ----
    f1_threshold: float = 0.5           # answer counts as correct if token-F1 >= this
    retrieval_cost: float = 0.05        # utility penalty for using retrieval
    wrong_penalty: float = 0.25         # utility penalty for a confident wrong answer

    # ---- routers ----
    router_model: str = "hgb"           # hgb | logreg
    use_distilbert: bool = False        # experimental query-only DistilBERT router
    distilbert_epochs: int = 3

    # ---- evaluation ----
    bootstrap: int = 1000


def load_config(path: str | None = None, overrides: dict | None = None) -> Config:
    data: dict = {}
    if path:
        data = yaml.safe_load(Path(path).read_text()) or {}
    data.update(overrides or {})
    valid = {f.name for f in dataclasses.fields(Config)}
    unknown = set(data) - valid
    if unknown:
        raise ValueError(f"Unknown config keys (typo?): {sorted(unknown)}")
    cfg = Config(**data)
    if not 0 < cfg.train_frac < 1 or not 0 < cfg.dev_frac < 1 or cfg.train_frac + cfg.dev_frac >= 1:
        raise ValueError("train_frac and dev_frac must leave a non-empty test split")
    return cfg
