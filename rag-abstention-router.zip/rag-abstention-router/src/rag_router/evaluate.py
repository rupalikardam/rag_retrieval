"""Head-to-head evaluation on the held-out TEST split.

All thresholds/hyper-parameters are fit on train/dev only. Test is touched once.
"""
from __future__ import annotations

import json
import logging
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import confusion_matrix, f1_score as sk_f1

from .config import Config
from .labeling import outcomes_path
from .router import ROUTER_VARIANTS, Router
from .utility import ABSTAIN, ACTIONS, NO_RETRIEVE, RETRIEVE, action_utilities, oracle_actions

log = logging.getLogger(__name__)


def routers_dir(cfg: Config) -> Path:
    d = Path(cfg.run_dir) / "routers"
    d.mkdir(parents=True, exist_ok=True)
    return d


# ----------------------------------------------------------------------------- training
def train_routers(cfg: Config) -> None:
    df = pd.read_csv(outcomes_path(cfg))
    tr = df[df["split"] == "train"].reset_index(drop=True)
    y = oracle_actions(action_utilities(tr, cfg.retrieval_cost, cfg.wrong_penalty))
    log.info("Train oracle-label distribution: %s",
             {ACTIONS[k]: int(v) for k, v in zip(*np.unique(y, return_counts=True))})
    for name, groups in ROUTER_VARIANTS.items():
        r = Router(groups, cfg.router_model, cfg.seed).fit(tr, y)
        r.save(routers_dir(cfg) / (name.replace("[", "_").replace("]", "").replace("+", "-") + ".joblib"))
        log.info("trained %s", name)

    if cfg.use_distilbert:
        from .distilbert_router import train_and_predict
        rest = df[df["split"] != "train"].reset_index(drop=True)
        preds = train_and_predict(tr["question"].tolist(), y, rest["question"].tolist(),
                                  epochs=cfg.distilbert_epochs, seed=cfg.seed, device=cfg.device)
        pd.DataFrame({"id": rest["id"], "action": preds}).to_csv(
            routers_dir(cfg) / "distilbert_preds.csv", index=False)
        log.info("trained distilbert router")


# ----------------------------------------------------------------------------- scoring
def cost_per_query(actions: np.ndarray, uses_param: bool, uses_retr: bool, uses_rag: bool) -> dict:
    """Average retrieval calls and LLM calls per query, counting the cost of the router's own inputs."""
    n = len(actions)
    retrieval = n if (uses_retr or uses_rag) else int((actions == RETRIEVE).sum())
    cb = n if uses_param else int((actions == NO_RETRIEVE).sum())
    rag = n if uses_rag else int((actions == RETRIEVE).sum())
    return {"retrieval_calls": retrieval / n, "llm_calls": (cb + rag) / n}


def summarize(df: pd.DataFrame, U: np.ndarray, actions: np.ndarray) -> dict:
    n = len(df)
    ans = df["is_answerable"].to_numpy().astype(bool)
    cb = df["cb_correct"].to_numpy().astype(bool)
    rag = df["rag_correct"].to_numpy().astype(bool)
    abst = actions == ABSTAIN
    answered_correct = np.where(actions == NO_RETRIEVE, cb, np.where(actions == RETRIEVE, rag, False))
    answered = ~abst
    return {
        "utility": float(U[np.arange(n), actions].mean()),
        "accuracy": float((answered_correct | (abst & ~ans)).mean()),   # right answer OR right abstention
        "hallucination_rate": float((answered & ~answered_correct).mean()),  # answered but wrong
        "abstain_rate": float(abst.mean()),
        "false_abstain_rate": float((abst & ans).sum() / max(ans.sum(), 1)),  # abstained on answerable
        "answer_precision": float(answered_correct.sum() / max(answered.sum(), 1)),
        "retrieve_rate": float((actions == RETRIEVE).mean()),
    }


def bootstrap_ci(values: np.ndarray, idx: np.ndarray) -> tuple[float, float]:
    means = values[idx].mean(axis=1)
    return float(np.percentile(means, 2.5)), float(np.percentile(means, 97.5))


def _tune_conf_threshold(dev: pd.DataFrame, U_dev: np.ndarray) -> float:
    """RAG + abstain when rag_conf < tau; tau chosen on DEV to maximise utility."""
    cands = np.unique(np.quantile(dev["rag_conf"], np.linspace(0, 1, 101)))
    cands = np.concatenate([[-1.0], cands, [2.0]])  # -1: never abstain, 2: always abstain
    best, best_u = cands[0], -np.inf
    for t in cands:
        a = np.where(dev["rag_conf"].to_numpy() >= t, RETRIEVE, ABSTAIN)
        u = U_dev[np.arange(len(dev)), a].mean()
        if u > best_u:
            best, best_u = t, u
    return float(best)


# ----------------------------------------------------------------------------- main
def evaluate(cfg: Config) -> pd.DataFrame:
    df = pd.read_csv(outcomes_path(cfg))
    U_all = action_utilities(df, cfg.retrieval_cost, cfg.wrong_penalty)
    m_dev, m_te = (df["split"] == "dev").to_numpy(), (df["split"] == "test").to_numpy()
    dev, test = df[m_dev].reset_index(drop=True), df[m_te].reset_index(drop=True)
    U_dev, U_te = U_all[m_dev], U_all[m_te]
    n = len(test)

    # name -> (actions, uses_param, uses_retr, uses_rag)
    methods: dict[str, tuple[np.ndarray, bool, bool, bool]] = {
        "never_retrieve": (np.full(n, NO_RETRIEVE), True, False, False),
        "always_retrieve": (np.full(n, RETRIEVE), False, True, True),
    }
    tau = _tune_conf_threshold(dev, U_dev)
    methods["rag+conf_threshold"] = (np.where(test["rag_conf"].to_numpy() >= tau, RETRIEVE, ABSTAIN),
                                     False, True, True)
    methods["always_abstain"] = (np.full(n, ABSTAIN), False, False, False)

    for name, groups in ROUTER_VARIANTS.items():
        p = routers_dir(cfg) / (name.replace("[", "_").replace("]", "").replace("+", "-") + ".joblib")
        if not p.exists():
            raise FileNotFoundError(f"{p} missing - run the `train` stage first")
        methods[name] = (Router.load(p).predict(test), "param" in groups,
                         "retr" in groups or "rag" in groups, "rag" in groups)

    db = routers_dir(cfg) / "distilbert_preds.csv"
    if cfg.use_distilbert and db.exists():
        pred = pd.read_csv(db, dtype={"id": str}).set_index("id")["action"]
        methods["router[distilbert:query]"] = (test["id"].astype(str).map(pred).to_numpy().astype(int),
                                               False, False, False)

    oracle = oracle_actions(U_te)
    methods["ORACLE"] = (oracle, False, False, False)

    rng = np.random.default_rng(cfg.seed)
    boot_idx = rng.integers(0, n, size=(cfg.bootstrap, n))
    base_u = U_te[np.arange(n), methods["always_retrieve"][0]]

    rows = []
    for name, (acts, up, ur, ug) in methods.items():
        s = summarize(test, U_te, acts)
        u_vec = U_te[np.arange(n), acts]
        lo, hi = bootstrap_ci(u_vec, boot_idx)
        d_lo, d_hi = bootstrap_ci(u_vec - base_u, boot_idx)
        row = {"method": name, **s, "utility_ci_lo": lo, "utility_ci_hi": hi,
               "dutil_vs_always_retrieve": float((u_vec - base_u).mean()),
               "dutil_ci_lo": d_lo, "dutil_ci_hi": d_hi, **cost_per_query(acts, up, ur, ug)}
        if name.startswith("router["):
            row["routing_accuracy"] = float((acts == oracle).mean())
            row["routing_macro_f1"] = float(sk_f1(oracle, acts, average="macro", labels=[0, 1, 2],
                                                  zero_division=0))
        rows.append(row)
    res = pd.DataFrame(rows)

    out = Path(cfg.run_dir) / "results"
    out.mkdir(exist_ok=True)
    res.to_csv(out / "results.csv", index=False)
    _write_markdown(res, cfg, tau, out / "results.md")
    _write_diagnostics(cfg, test, methods, oracle, tau, out / "diagnostics.json")
    _plot(res, out / "utility.png")
    log.info("Results written to %s", out)
    return res


def _write_markdown(res: pd.DataFrame, cfg: Config, tau: float, path: Path) -> None:
    cols = ["method", "utility", "accuracy", "hallucination_rate", "abstain_rate",
            "false_abstain_rate", "retrieve_rate", "llm_calls", "retrieval_calls"]
    lines = [f"Test-split results (utility: correct=+1, wrong=-{cfg.wrong_penalty}, "
             f"retrieval cost={cfg.retrieval_cost}; conf-threshold tau={tau:.3f} tuned on dev).\n",
             "| " + " | ".join(cols + ["Δutil vs always_retrieve [95% CI]"]) + " |",
             "|" + "---|" * (len(cols) + 1)]
    for r in res.itertuples():
        vals = [f"{getattr(r, c):.3f}" if c != "method" else r.method for c in cols]
        vals.append(f"{r.dutil_vs_always_retrieve:+.3f} [{r.dutil_ci_lo:+.3f}, {r.dutil_ci_hi:+.3f}]")
        lines.append("| " + " | ".join(vals) + " |")
    path.write_text("\n".join(lines) + "\n")


def _write_diagnostics(cfg, test, methods, oracle, tau, path: Path) -> None:
    ans = test[test["is_answerable"]]
    diag = {
        "n_test": len(test), "test_unanswerable_frac": float((~test["is_answerable"]).mean()),
        "closed_book_acc_on_answerable": float(ans["cb_correct"].mean()),
        "rag_acc_on_answerable": float(ans["rag_correct"].mean()),
        "gold_passage_in_topk": float(ans["gold_in_topk"].mean()),
        "gold_passage_at_top1": float(ans["gold_at_top1"].mean()),
        "oracle_action_distribution": {ACTIONS[k]: int(v) for k, v in zip(*np.unique(oracle, return_counts=True))},
        "conf_threshold_tau": tau,
        "confusion_matrices (rows=oracle, cols=predicted; order=no_retrieve,retrieve,abstain)": {
            name: confusion_matrix(oracle, a, labels=[0, 1, 2]).tolist()
            for name, (a, *_rest) in methods.items() if name.startswith("router[")},
    }
    path.write_text(json.dumps(diag, indent=2))


def _plot(res: pd.DataFrame, path: Path) -> None:
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        return
    r = res.sort_values("utility")
    err = np.vstack([r["utility"] - r["utility_ci_lo"], r["utility_ci_hi"] - r["utility"]])
    fig, ax = plt.subplots(figsize=(8, 0.45 * len(r) + 1.5))
    ax.barh(r["method"], r["utility"], xerr=err, color="#4C78A8")
    ax.set_xlabel("Mean utility on test (95% bootstrap CI)")
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)
