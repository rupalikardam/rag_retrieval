import numpy as np
import pandas as pd
import pytest

from rag_router.cli import run_all
from rag_router.config import load_config
from rag_router.data import assign_splits
from rag_router.metrics import f1_score, is_correct, normalize_answer
from rag_router.retriever import BM25Retriever
from rag_router.utility import ABSTAIN, NO_RETRIEVE, RETRIEVE, action_utilities, oracle_actions


def test_normalize_and_f1():
    assert normalize_answer("The  Eiffel Tower!") == "eiffel tower"  # official SQuAD rules
    assert f1_score("Eiffel Tower", "the eiffel tower") == 1.0
    assert 0 < f1_score("big Eiffel Tower", "Eiffel Tower") < 1


def test_unanswerable_is_never_correct():
    assert not is_correct("anything", [])
    assert is_correct("Paris", ["Paris"])


def test_bm25_finds_right_passage():
    docs = ["cats purr and sleep", "the capital of France is Paris", "dogs bark loudly"]
    idx, sc = BM25Retriever(docs).search(["what is the capital of France"], 2)
    assert idx[0][0] == 1 and sc[0][0] >= sc[0][1]


def test_bm25_k_larger_than_corpus():
    idx, _ = BM25Retriever(["a b", "c d"]).search(["a"], 10)
    assert idx.shape == (1, 2)


def test_oracle_dominates_every_fixed_action():
    rng = np.random.default_rng(0)
    df = pd.DataFrame({"cb_correct": rng.random(500) < 0.2, "rag_correct": rng.random(500) < 0.6,
                       "is_answerable": rng.random(500) < 0.5})
    df.loc[~df.is_answerable, ["cb_correct", "rag_correct"]] = False
    U = action_utilities(df, 0.05, 0.25)
    best = U[np.arange(500), oracle_actions(U)].mean()
    for a in (NO_RETRIEVE, RETRIEVE, ABSTAIN):
        assert best >= U[:, a].mean()


def test_oracle_prefers_cheaper_action_on_ties():
    df = pd.DataFrame({"cb_correct": [True], "rag_correct": [True], "is_answerable": [True]})
    assert oracle_actions(action_utilities(df, 0.05, 0.25))[0] == NO_RETRIEVE


def test_splits_do_not_leak_groups():
    df = pd.DataFrame({"group": np.repeat(np.arange(50), 4)})
    out = assign_splits(df, 0.6, 0.2, seed=1)
    assert out.groupby("group")["split"].nunique().max() == 1
    assert set(out.split) == {"train", "dev", "test"}


def test_config_rejects_typos():
    with pytest.raises(ValueError):
        load_config(None, {"n_question": 10})


@pytest.fixture(scope="module")
def results(tmp_path_factory):
    run = tmp_path_factory.mktemp("run")
    cfg = load_config("configs/synthetic_demo.yaml", {"run_dir": str(run), "bootstrap": 200})
    return run_all(cfg).set_index("method"), cfg


def test_end_to_end_outputs(results):
    res, cfg = results
    from pathlib import Path
    for f in ("results.csv", "results.md", "diagnostics.json", "utility.png"):
        assert (Path(cfg.run_dir) / "results" / f).exists()
    assert {"always_retrieve", "never_retrieve", "ORACLE", "router[query+param+retr]"} <= set(res.index)


def test_oracle_is_upper_bound(results):
    res, _ = results
    assert res["utility"].idxmax() == "ORACLE" or res.loc["ORACLE", "utility"] >= res["utility"].max() - 1e-9


def test_router_beats_standard_rag(results):
    res, _ = results
    assert res.loc["router[query+param+retr]", "utility"] > res.loc["always_retrieve", "utility"]


def test_metrics_are_valid_probabilities(results):
    res, _ = results
    for c in ["accuracy", "hallucination_rate", "abstain_rate", "false_abstain_rate", "retrieve_rate"]:
        assert res[c].between(0, 1).all()


def test_pipeline_is_deterministic(tmp_path):
    a = run_all(load_config("configs/synthetic_demo.yaml", {"run_dir": str(tmp_path / "a"), "bootstrap": 50}))
    b = run_all(load_config("configs/synthetic_demo.yaml", {"run_dir": str(tmp_path / "b"), "bootstrap": 50}))
    pd.testing.assert_frame_equal(a, b)
